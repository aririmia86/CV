package Utiles;

public class Bloque {
	private Punto supIzq;
	private Punto infDer;
	
	public Bloque(Punto supIzq, Punto infDer) {
		this.supIzq = supIzq;
		this.infDer = infDer;
	}

	public Punto getSupIzq() {
		return supIzq;
	}

	public void setSupIzq(Punto supIzq) {
		this.supIzq = supIzq;
	}

	public Punto getInfDer() {
		return infDer;
	}

	public void setInfDer(Punto infDer) {
		this.infDer = infDer;
	}

	public String toString() {
		return "Bloque [supIzq=" + supIzq + ", infDer=" + infDer + "]";
	}
	
	
}
