package Utiles;

import java.util.LinkedList;
import java.util.List;
import static java.lang.Math.pow;

public class Momentos {

	public static double getMomentoGeometrico(int p, int q, int[][] M) {
		double res = 0.0;
		for (int x = 0; x < M.length; x++) {
			for (int y = 0; y < M[0].length; y++) {
				res += pow(x, p) * pow(y, q) * M[x][y];
			}
		}
		return res;
	}

	public static double getMomentoCentral(int p, int q, int[][] M) {
		double res = 0.0;
		List<Double> centroide = calculaCentroide(M);
		double xCentroide = centroide.get(0);
		double yCentroide = centroide.get(1);
		for (int x = 0; x < M.length; x++) {
			for (int y = 0; y < M[0].length; y++) {
				res += pow((x - xCentroide), p) * pow((y - yCentroide), q)
						* M[x][y];
			}
		}
		return res;
	}

	public static List<Double> calculaCentroide(int[][] M) {
		List<Double> res = new LinkedList<Double>();
		double m00 = getMomentoGeometrico(0, 0, M);
		double m01 = getMomentoGeometrico(0, 1, M);
		double m10 = getMomentoGeometrico(1, 0, M);
		double xCentroide = m10 / m00;
		double yCentroide = m01 / m00;
		res.add(xCentroide);
		res.add(yCentroide);
		return res;
	}

	public static List<Double> getMomentosInvariantes(int[][] M) {

		List<Double> res = new LinkedList<Double>();
		double n20 = n(2, 0, M);
		double n02 = n(0, 2, M);
		double n11 = n(1, 1, M);
		double n30 = n(3, 0, M);
		double n03 = n(0, 3, M);
		double n12 = n(1, 2, M);
		double n21 = n(2, 1, M);

		double i1 = n20 + n02;
		double i2 = (double) (pow(n20 - n02, 2) + 4 * pow(n11, 2));
		double i3 = (double) (pow(n30 - 3 * n12, 2) + pow(3 * n21 - n03, 2));
		double i4 = (double) (pow(n30 + n12, 2) + pow(n21 + n03, 2));
		double i5 = (double) ((n30 - 3 * n12) * (n30 + n12)
				* (pow(n30 + n12, 2) - 3 * pow(n21 + n03, 2)) + (3 * n21 - n03)
				* (n21 + n03) * (3 * pow(n30 + n12, 2) - pow(n21 + n03, 2)));
		double i6 = (double) (n20 - n02)
				* (pow(n30/* */ + n12, 2) - pow(n21 + n03, 2)) + 4 * n11
				* (n30 + n12) * (n21 + n03);
		double i7 = (double) (3 * n21 - n03) * (n30 + n12)
				* ((pow(n30 + n12, 2) - 3 * pow(n21 + n03, 2)))
				+ (3 * n12 - n30) * (n21 + n03)
				* (3 * pow(n30 + n12, 2) - pow(n21 + n03, 2));

		res.add(i1);
		res.add(i2);
		res.add(i3);
		res.add(i4);
		res.add(i5);
		res.add(i6);
		res.add(i7);
		return res;
	}

	private static double n(int p, int q, int[][] M) {
		double expo = 0;
		expo = ((p + q) / 2.0) + 1.0;
		double den = pow(getMomentoCentral(0, 0, M), expo);
		return (double) (getMomentoCentral(p, q, M) / den);
	}

}
