package Utiles;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class PIBR {

	public static double getMomentoGeometrico(int p, int q, int[][] M) {
		double res = 0.0;
		Map<Integer, List<Bloque>> bloques = resultado(M);
		for (Integer nivelGris : bloques.keySet()) {
			List<Bloque> lb = bloques.get(nivelGris);
			double momento = calculaMomentoBinario(lb, p, q);
			res += nivelGris * momento;
		}
		return res;
	}

	public static double calculaMomentoBinario(List<Bloque> lb, int p, int q) {
		double res = 0.0;
		for (Bloque b : lb) {
			double valorX = 0.0;
			double valorY = 0.0;
			int x1 = b.getSupIzq().getCoordX();
			int x2 = b.getInfDer().getCoordX();
			int y1 = b.getSupIzq().getCoordY();
			int y2 = b.getInfDer().getCoordY();
			for (int x = x1; x <= x2; x++) {
				valorX += Math.pow(x, p);
			}
			for (int y = y1; y <= y2; y++) {
				valorY += Math.pow(y, q);
			}
			res += valorX * valorY;
		}
		return res;
	}

	public static Map<Integer, List<Bloque>> resultado(int[][] M) {
		// Estructura con Clave el Nivel de gris y Valor la Lista de bloques
		Map<Integer, List<Bloque>> y_0 = getBloques(M, 0);
		for (int i = 1; i < M.length; i++) {
			Map<Integer, List<Bloque>> y_i = getBloques(M, i);
			// Comparamos los niveles de gris de la fila actual con la fila 0
			for (Integer nivelGris : y_i.keySet()) {
				List<Bloque> lb_i = y_i.get(nivelGris);
				// Si el nivel de gris esta ya almacenado en la fila 0
				if (y_0.containsKey(nivelGris)) {
					List<Bloque> lb_0 = y_0.get(nivelGris);
					// Para cada bloque de ese nivel de gris
					for (Bloque b_i : lb_i) {
						Integer anchoBloque_i = b_i.getInfDer().getCoordY()
								- b_i.getSupIzq().getCoordY();
						Boolean encontrado = false;
						// Comprobamos si coincide con algun bloque de la fila 0
						for (Bloque b_0 : lb_0) {
							Integer anchoBloque_0 = b_0.getInfDer().getCoordY()
									- b_0.getSupIzq().getCoordY();
							// Comprobamos si coinciden anchuras y se encuentra
							// justo debajo del bloque
							if (anchoBloque_0.equals(anchoBloque_i)
									&& b_0.getInfDer().getCoordX().equals(
											b_i.getInfDer().getCoordX() - 1)
									&& b_0.getSupIzq().getCoordY().equals(
											b_i.getSupIzq().getCoordX() - 1)) {
								// El fin del bloque esta en la linea i
								b_0.setInfDer(b_i.getInfDer());
								encontrado = true;
								break;
							}
						}
						// Si no hemos encontrado un bloque que coincide
						if (!encontrado) {
							// Lo anyadimos a la lista de bloques
							lb_0.add(b_i);
						}
					}
				}
				// Si no contiene ese nivel de gris
				else {
					// Lo anyadimos directamente a los bloques almacenados
					y_0.put(nivelGris, lb_i);
				}
			}
		}
		return y_0;
	}

	public static Map<Integer, List<Bloque>> getBloques(int[][] M, int i) {
		Map<Integer, List<Bloque>> res = new HashMap<Integer, List<Bloque>>();
		for (int j = 0; j < M[0].length; j++) {
			Integer nivelGris = M[i][j];
			// Si hay bloques con ese nivel de gris
			if (res.containsKey(nivelGris)) {
				// Esto nos permite comprobar si insertamos el pixel en un
				// bloque o no
				Boolean insertado = false;
				List<Bloque> lb = res.get(nivelGris);
				// Comprobamos si el ultimo bloque insertado coincide con el
				// pixel que estamos insertando
				Bloque b = lb.get(lb.size() - 1);
				if (b.getInfDer().getCoordY().equals(j - 1)) {
					b.setInfDer(new Punto(i, j));
					insertado = true;
				}
				// Si no lo hemos insertado en el ultimo bloque nos creamos un
				// nuevo bloque con ese pixel y lo a�adimos a la lista de
				// bloques almacenados
				if (!insertado) {
					b = new Bloque(new Punto(i, j), new Punto(i, j));
					lb.add(b);
				}
			}
			// Si no hemos almacenado aun ese nivel de gris nos creamos una
			// nueva clave en la funcion con ese nivel de gris y anyadimos a
			// la lista el nuevo bloque creado con el pixel
			else {
				List<Bloque> lb = new LinkedList<Bloque>();
				Bloque b = new Bloque(new Punto(i, j), new Punto(i, j));
				lb.add(b);
				res.put(nivelGris, lb);
			}
		}
		return res;
	}

}
